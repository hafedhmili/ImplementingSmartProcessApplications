package spa.samples.health.domain;

public interface ActType extends HealthEpisodeType {
	
}
