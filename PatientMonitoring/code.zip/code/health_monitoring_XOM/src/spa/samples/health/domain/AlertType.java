package spa.samples.health.domain;

public enum AlertType {
	ForTheRecord, NeedsToBeCheckedMidTerm, NeedsToBecheckedShortTerm, RequiresEmergency
}
