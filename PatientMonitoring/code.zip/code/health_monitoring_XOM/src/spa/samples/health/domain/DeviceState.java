/**
 * 
 */
package spa.samples.health.domain;

/**
 * @author hafedhmili
 *
 */
public enum DeviceState {
	
	Off, On, Broken, WorkingCondition, LowCharge

}
