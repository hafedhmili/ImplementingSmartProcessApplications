package spa.samples.health.domain;

public interface HealthConditionType extends SPAType {
	
}
