package spa.samples.health.domain;

public interface HealthEpisodeType extends SPAType {
	//	OnSet, Diagnosis, Healing, Treatment, Medication, Monitoring, Cure, Injury, Infection, Exacerbation, Relief, Remission;
}
