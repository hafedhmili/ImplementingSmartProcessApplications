package spa.samples.health.domain;

public enum IntensityLevel {
Low, Moderate, High
}
