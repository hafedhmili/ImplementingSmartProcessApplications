package spa.samples.health.domain;

public enum PatientStateType {
	Normal, BorderlineWithinBounds, NeedsAttentionEventually, NeedsAttentionSoon, Emergency
}
