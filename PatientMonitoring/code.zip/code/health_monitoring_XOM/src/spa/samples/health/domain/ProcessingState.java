package spa.samples.health.domain;

public enum ProcessingState {
	ToBeProcessed, InProgress,Rejected,Skipped,Processed,Archived

}
