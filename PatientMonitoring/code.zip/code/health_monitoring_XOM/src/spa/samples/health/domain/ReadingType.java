package spa.samples.health.domain;

public enum ReadingType {
	BloodPressure, BloodOxygenSaturation, Pulse, Temperature, HeartBeat, EKG, BreathingPace, BreathingStyle
}
