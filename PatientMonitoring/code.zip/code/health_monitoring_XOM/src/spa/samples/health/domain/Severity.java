package spa.samples.health.domain;

public enum Severity {
	Low, Moderate, High, VeryHigh
}
