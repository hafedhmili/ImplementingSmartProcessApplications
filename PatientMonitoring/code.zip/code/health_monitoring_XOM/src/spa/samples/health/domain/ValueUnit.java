package spa.samples.health.domain;

public enum ValueUnit {
	metre,degree_celcius,gram_per_liter,ppm, pulses_per_minute
}
