/**
 * 
 */
package spa.samples.health.impl;

import java.time.Instant;

/**
 * Author: Hafedh Mili
 */
public class MainClass {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Instant maintenant = Instant.now();
		System.out.println("the current instant is: " + maintenant);

	}

}
