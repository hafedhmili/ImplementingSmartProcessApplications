/**
 * 
 */
package spa.samples.health.util;

/**
 * Author: Hafedh Mili
 */
public enum DurationUnit {
	Second, Minute, Hour, Day, Week, Month, Year

}
